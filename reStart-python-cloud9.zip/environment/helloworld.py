"""
Your module description
"""

print("Python has three data types :int, float , and complex")
myvalue=1

print(myvalue)
print(type(myvalue))
print(str(myvalue) + " is of the data type " + str(type(myvalue)))
