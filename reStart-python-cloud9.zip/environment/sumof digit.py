"""
Your module description
"""

num = input("enter your no ")    
sum = 0
for i in num:
    sum = sum + int(i)
print(sum)