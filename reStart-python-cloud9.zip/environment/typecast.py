"""
Your module description
"""
thislist = ['john','sopia','fun']
for i in thislist:
    print(i,end= ' ')
    