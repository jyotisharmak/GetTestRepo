"""
Your module description
"""

n = int(input("enter the no "))
i =1 
fact =1
while (i<=n):
    fact = fact*i
    i=i+1
print(fact)
    