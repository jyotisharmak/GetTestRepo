"""
Your module description
"""
bananas =int(input("Enter your no. of bananas "))
if (bananas >= 5):
    print("′I have a large bunch of banana")
elif (bananas <5):
    print("I have a small bunch of bananas")
else:
    print("I don’t have any bananas")