"""
Your module description
"""
myfruitlist = ["apple", "cherry", "mango"]
print(myfruitlist)
print(type(myfruitlist))
print(myfruitlist[0])
print(myfruitlist[1])
myfruitlist[2] = "orange"
print(myfruitlist)
myFinalAnswerTuple = ("apple", "banana", "pineapple")
print(myFinalAnswerTuple)
print(type(myFinalAnswerTuple))

print(myFinalAnswerTuple[0])
print(myFinalAnswerTuple[1])
myFavoriteFruitDictionary = {
  "Akua" : "apple",
  "Saanvi" : "banana",
  "Paulo" : "pineapple"
}
print(myFavoriteFruitDictionary)
print(type(myFavoriteFruitDictionary))
print(myFavoriteFruitDictionary["Akua"])