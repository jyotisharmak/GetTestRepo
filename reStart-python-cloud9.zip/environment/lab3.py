"""
Your module description
"""
mystring = "This is a string"
print(mystring)
print(type(mystring))
print(str(mystring) + " is of the data type " + str(type(mystring)))