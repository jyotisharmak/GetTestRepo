"""
Your module description
"""
firstString = "water"
secondString = "fall"
thirdString = firstString + secondString
print(thirdString)
name = input("What is your name? ")
print(name)
color = input("What is your fav color?")
animal = input("what is your fav animal?")

print("{}, you like a {},{}!".format(name,color,animal))